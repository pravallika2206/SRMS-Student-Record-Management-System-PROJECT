SRMS Windows Single-Threaded Server (Option 2)
Files:
- server.cpp : single-threaded Winsock2 HTTP server (C++17)
- public/    : frontend files (index.html, style.css, app_form.js)
- students.csv - tab-separated student storage
- users.csv - demo users (username, password, role)

Compile with MinGW (MSYS2):
g++ server.cpp -static -lws2_32 -std=c++17 -O2 -o server.exe

Or with MSVC (Developer Command Prompt):
cl /EHsc server.cpp ws2_32.lib

Run:
server.exe
Open browser: http://localhost:8080

Notes:
- Single-threaded: serves one connection at a time — simpler, smaller, perfect for testing/demo.
- If firewall prompts appear, allow server through firewall.
- For production, use secure password hashing and a proper database.
